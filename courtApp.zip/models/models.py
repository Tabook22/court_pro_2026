from flask_login import UserMixin
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from enum import Enum
from sqlalchemy import Enum as SQLAlchemyEnum

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'tbluser'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    tel = db.Column(db.String(20), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)


class CaseStatus(Enum):
    active = 'active'
    inactive= 'inactive'
    finished = 'finished'
    postponed = 'postponed'
    in_session = 'in session'

class Case(db.Model):
    __tablename__ = 'tblcase'
    id = db.Column(db.Integer, primary_key=True)
    case_number = db.Column(db.String(50), nullable=False)
    case_date = db.Column(db.Date, nullable=False)
    added_date = db.Column(db.DateTime, default=datetime.utcnow)
    c_order = db.Column(db.Integer, nullable=False)
    next_session_date = db.Column(db.String(100), nullable=False)
    session_result = db.Column(db.Text, nullable=False)
    num_sessions = db.Column(db.Integer, nullable=False)
    case_subject = db.Column(db.String(200), nullable=False)
    defendant = db.Column(db.String(100), nullable=False)
    plaintiff = db.Column(db.String(100), nullable=False)
    prosecution_number = db.Column(db.String(50), nullable=False)
    police_department = db.Column(db.String(150), nullable=False)
    police_case_number = db.Column(db.String(50), nullable=False)
    status = db.Column(SQLAlchemyEnum(CaseStatus), default=CaseStatus.inactive, nullable=False)



class DisplayCase(db.Model):
    __tablename__ = 'tbldisply'
    id = db.Column(db.Integer, primary_key=True)
    case_id = db.Column(db.Integer, db.ForeignKey('tblcase.id'), nullable=False)
    display_order = db.Column(db.Integer, nullable=False)
    custom_order = db.Column(db.Integer, nullable=True)  # Add this line
    added_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    case = db.relationship('Case', backref='display_entries')

class DisplaySettings(db.Model):
    __tablename__ = 'display_settings'
    id = db.Column(db.Integer, primary_key=True)
    field_name = db.Column(db.String(50), nullable=False)
    field_name_ar=db.Column(db.String(50), nullable=True)
    is_visible = db.Column(db.Boolean, default=True)