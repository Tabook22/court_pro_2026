# excel_processor.py
from flask import jsonify
import pandas as pd
from googletrans import Translator
import json
import numpy as np
from datetime import datetime, timezone
import os

class ExcelProcessor:
    def __init__(self, json_storage_path='json_storage'):
        """
        Initialize the Excel Processor
        
        Args:
            json_storage_path (str): Path where JSON files will be stored
        """
        self.translator = Translator()
        self.json_storage_path = json_storage_path
        # Create storage directory if it doesn't exist
        os.makedirs(json_storage_path, exist_ok=True)
        
        # Predefined translations for known headers
        self.known_translations = {
            "الرقم المقابل": "prosecution_number",
            "تاريخ الجلسة المقبلة": "next_session_date",
            "مستأنف ضده": "defendant",
            "مستأنف": "plaintiff",
            "رقم الدعوى": "case_number",
            "م": "c_order"
        }
        
    def _translate_headers(self, headers):
        """
        Translate headers from Arabic to English using predefined mappings
        
        Args:
            headers (list): List of column headers in Arabic
            
        Returns:
            dict: Mapping of original headers to translated headers
        """
        translated_headers = {}
        for header in headers:
            try:
                # Check if header exists in known translations
                if header in self.known_translations:
                    translated_headers[header] = self.known_translations[header]
                else:
                    # For unknown headers, use Google Translate as fallback
                    translated = self.translator.translate(header, src='ar', dest='en')
                    processed_header = self._process_header_name(translated.text)
                    translated_headers[header] = processed_header
                    print(f"Warning: Unknown header '{header}' translated to '{processed_header}'")
            except Exception as e:
                print(f"Translation error for header '{header}': {str(e)}")
                # Fallback if translation fails
                translated_headers[header] = self._process_header_name(header)
        return translated_headers
    
    def _process_header_name(self, header):
        """
        Convert header to snake_case and clean it
        
        Args:
            header (str): Header text to process
            
        Returns:
            str: Processed header name
        """
        # Remove special characters and convert to lowercase
        processed = ''.join(c.lower() if c.isalnum() else '_' for c in str(header))
        # Replace multiple underscores with single underscore
        processed = '_'.join(filter(None, processed.split('_')))
        return processed.strip('_')  # Remove leading/trailing underscores
    
    def _detect_column_types(self, df):
        """
        Detect and standardize column types
        
        Args:
            df (pandas.DataFrame): DataFrame to analyze
            
        Returns:
            dict: Mapping of column names to their detected types
        """
        type_mapping = {}
        
        for column in df.columns:
            sample_data = df[column].dropna().head(10)  # Check first 10 non-null values
            
            if len(sample_data) == 0:
                type_mapping[column] = 'string'
                continue
                
            # Try common date formats
            date_formats = ['%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%Y/%m/%d', '%d-%m-%Y']
            is_date = False
            
            # First check if it's already a datetime
            if pd.api.types.is_datetime64_any_dtype(sample_data):
                type_mapping[column] = 'date'
                continue
                
            # Then try parsing as dates
            for date_format in date_formats:
                try:
                    # Try to convert the entire column to datetime
                    pd.to_datetime(sample_data, format=date_format)
                    type_mapping[column] = 'date'
                    is_date = True
                    break
                except (ValueError, TypeError):
                    continue
                    
            if is_date:
                continue
            
            # Check if numeric
            try:
                numeric_data = pd.to_numeric(sample_data, errors='raise')
                if numeric_data.apply(lambda x: float(x) % 1 == 0).all():
                    type_mapping[column] = 'integer'
                else:
                    type_mapping[column] = 'float'
            except (ValueError, TypeError):
                type_mapping[column] = 'string'
                
        return type_mapping

    def _format_value(self, value, column_type):
        """
        Format a value based on its column type
        
        Args:
            value: The value to format
            column_type (str): The type of the column ('date', 'integer', 'float', or 'string')
            
        Returns:
            Formatted value suitable for JSON
        """
        if pd.isna(value):
            return None
            
        try:
            if column_type == 'date':
                if isinstance(value, (datetime, pd.Timestamp)):
                    return value.strftime('%Y-%m-%d')
                return str(value)
            elif column_type == 'integer':
                return int(float(value))
            elif column_type == 'float':
                return float(value)
            else:
                return str(value)
        except (ValueError, TypeError):
            return str(value)

    def save_to_json(self, data, original_filename):
        """
        Save processed data to a JSON file
        
        Args:
            data (dict): Data to save
            original_filename (str): Name of the original Excel file
            
        Returns:
            str: Name of the saved JSON file
        """
        # Create a filename for the JSON file based on the original Excel filename
        base_name = os.path.splitext(original_filename)[0]
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        json_filename = f"{timestamp}.json"
        json_path = os.path.join(self.json_storage_path, json_filename)
        
        # Save the data to JSON file with proper encoding
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            
        return json_filename

    def process_excel_file(self, file_path):
        """
        Process the Excel file and return schema and data in JSON format
        
        Args:
            file_path (str): Path to the Excel file
            
        Returns:
            dict: Processing results including success status, schema, and data
        """
        try:
            # Read Excel file with proper encoding
            df = pd.read_excel(file_path)
            
            # Get original headers and translate them
            original_headers = df.columns.tolist()
            translated_headers = self._translate_headers(original_headers)
            
            # Create a mapping of translations for reference
            translation_mapping = {
                original: {
                    'translated': translated,
                    'original': original
                } for original, translated in translated_headers.items()
            }
            
            # Rename columns with translated headers
            df.columns = [translated_headers[col] for col in original_headers]
            
            # Detect column types
            column_types = self._detect_column_types(df)
            
            # Create schema
            schema = {
                'original_headers': original_headers,
                'translated_headers': translated_headers,
                'column_types': column_types,
                'row_count': len(df),
                'processed_date': datetime.now(timezone.utc).isoformat(),
                'translation_mapping': translation_mapping
            }
            
            # Convert data to JSON-compatible format
            data = []
            for _, row in df.iterrows():
                row_dict = {}
                for col in df.columns:
                    row_dict[col] = self._format_value(row[col], column_types[col])
                data.append(row_dict)
            
            result = {
                'schema': schema,
                'data': data
            }
            
            # Save to JSON file
            original_filename = os.path.basename(file_path)
            json_filename = self.save_to_json(result, original_filename)
            
            return {
                'success': True,
                'schema': schema,
                'data': data,
                'json_filename': json_filename,
                'message': 'File processed successfully',
                'row_count': len(df),
                'column_count': len(df.columns)
            }
            
        except Exception as e:
            print(f"Error processing Excel file: {str(e)}")  # For debugging
            return {
                'success': False,
                'error': str(e),
                'message': 'Error processing file'
            }

    def get_processed_data(self, json_filename):
        """
        Retrieve processed data from a saved JSON file
        
        Args:
            json_filename (str): Name of the JSON file to retrieve
            
        Returns:
            dict: The processed data or None if file not found
        """
        json_path = os.path.join(self.json_storage_path, json_filename)
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error reading JSON file: {str(e)}")
            return None