import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory, session
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timezone
from models import db, User, Case, DisplayCase, DisplaySettings, CaseStatus
import time
from excel_processor import ExcelProcessor
import json
from json_to_db import JsonToDatabase  # Add this import at the top
from collections import defaultdict
from flask_migrate import Migrate

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydb.db'
app.config['JSON_STORAGE'] = 'json_storage'


migrate = Migrate(app, db)

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize extensions
db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def load_user(user_id):
    #return User.query.get(int(user_id))
    return db.session.get(User, int(user_id))  # Updated from User.query.get()

@app.context_processor
def utility_processor():
    return {'now': datetime.now(timezone.utc)}

# Routes
@app.route('/')
def index():
    if not current_user.is_authenticated:
        return redirect(url_for('login'))
    cases = Case.query.order_by(Case.c_order).all()
    return render_template('index.html', cases=cases)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'excelFile' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'}), 400
    
    file = request.files['excelFile']
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'}), 400
    
    if file and file.filename.lower().endswith(('.xls', '.xlsx')):
        # Get the current date to create folders
        current_date = datetime.now()
        year_folder = os.path.join(app.config['UPLOAD_FOLDER'], str(current_date.year))
        month_folder = os.path.join(year_folder, current_date.strftime('%m-%B'))
        date_folder = os.path.join(month_folder, current_date.strftime('%d'))
        
        # Create the nested folders if they don't exist
        os.makedirs(date_folder, exist_ok=True)
        
        # Generate a timestamp for the filename
        timestamp = int(time.time())
        
        # Get the file extension
        _, file_extension = os.path.splitext(file.filename)
        
        # Create the new filename with timestamp
        new_filename = f"{timestamp}{file_extension}"
        
        # Secure the filename and save the file in the date folder
        filename = secure_filename(new_filename)
        file_path = os.path.join(date_folder, filename)
        file.save(file_path)
        
        return jsonify({'success': True, 'message': f'File uploaded successfully to {file_path}'}), 200
    else:
        return jsonify({'success': False, 'message': 'Invalid file type'}), 400

# this will import the JSON data into the database "tblcase"
@app.route('/import_to_database', methods=['POST'])
@login_required
def import_to_database():
    if not current_user.is_admin:
        return jsonify({'success': False, 'message': 'Access denied'})

    json_filename = request.form.get('json_filename')
    if not json_filename:
        return jsonify({'success': False, 'message': 'No JSON file specified'})

    try:
        importer = JsonToDatabase()
        result = importer.process_json_file(json_filename)
        
        if not result['success']:
            print("Import failed:", result.get('error', 'Unknown error'))
            return jsonify({
                'success': False,
                'message': f"Import failed: {result.get('error', 'Unknown error')}"
            })
            
        return jsonify(result)
        
    except Exception as e:
        print("Exception during import:", str(e))
        return jsonify({
            'success': False,
            'message': f'Error during import: {str(e)}'
        })

@app.route('/process_excel', methods=['POST'])
@login_required
def process_excel():
    year = request.form.get('year')
    month = request.form.get('month')
    file = request.form.get('file')
    
    if not year or not month or not file:
        return jsonify({'success': False, 'message': 'Invalid file information'})
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], year, month, file)
    
    if not os.path.exists(file_path):
        return jsonify({'success': False, 'message': 'File not found'})
    
    # Process the Excel file
    processor = ExcelProcessor(json_storage_path=app.config['JSON_STORAGE'])
    result = processor.process_excel_file(file_path)
    
    if result['success']:
        # Store the processed data in a session variable for temporary access
        session['processed_excel_data'] = result
        return jsonify({
            'success': True,
            'message': 'File processed successfully',
            'schema': result['schema'],
            'json_filename': result['json_filename']
        })
    else:
        return jsonify({
            'success': False,
            'message': f'Error processing file: {result["error"]}'
        })


# Change to
@app.route('/processed_json/<filename>')
@login_required
def serve_processed_json(filename):
    return send_from_directory(app.config['JSON_STORAGE'], filename)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        existing_user = User.query.filter_by(username=request.form['username']).first()
        if existing_user:
            flash('Username already exists', 'danger')
            return redirect(url_for('login'))
        
        user = User(
            username=request.form['username'],
            password=generate_password_hash(request.form['password']),
            name=request.form['name'],
            email=request.form['email'],
            tel=request.form['tel'],
            is_admin=bool(int(request.form.get('is_admin', 0)))
        )
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. Please login.', 'success')
        return redirect(url_for('login'))
    return redirect(url_for('login'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Uploaded exce files listing:@app.route('/list_files', methods=['GET'])
@app.route('/list_files')
@login_required
def list_files():
    files_by_year_month = defaultdict(lambda: defaultdict(list))

    if os.path.exists(app.config['UPLOAD_FOLDER']):
        for year in os.listdir(app.config['UPLOAD_FOLDER']):
            year_path = os.path.join(app.config['UPLOAD_FOLDER'], year)
            if os.path.isdir(year_path):
                for month in os.listdir(year_path):
                    month_path = os.path.join(year_path, month)
                    if os.path.isdir(month_path):
                        for day in os.listdir(month_path):
                            day_path = os.path.join(month_path, day)
                            if os.path.isdir(day_path):
                                files = os.listdir(day_path)
                                if files:
                                    files_by_year_month[year][month].extend(
                                        [os.path.join(day, file) for file in files]
                                    )
                                else:
                                    try:
                                        os.rmdir(day_path)
                                        print(f"Deleted empty folder: {day_path}")
                                    except OSError as e:
                                        print(f"Error deleting folder {day_path}: {e}")

    return render_template('list_files.html', files_by_year_month=files_by_year_month)

@app.route('/delete_file', methods=['POST'])
@login_required
def delete_file():
    year = request.form.get('year')
    month = request.form.get('month')
    file = request.form.get('file')
    
    if not year or not month or not file:
        return jsonify({'success': False, 'message': 'Invalid file information'}), 400
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], year, month, file)
    
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
            # Check if the day folder is empty and remove it if so
            day_folder = os.path.dirname(file_path)
            if not os.listdir(day_folder):
                os.rmdir(day_folder)
            return jsonify({'success': True, 'message': 'File deleted successfully'}), 200
        except Exception as e:
            return jsonify({'success': False, 'message': f'Error deleting file: {str(e)}'}), 500
    else:
        return jsonify({'success': False, 'message': 'File not found'}), 404


@app.route('/view_file/<year>/<month>/<path:file>')
@login_required
def view_file(year, month, file):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], year, month, file)
    return send_from_directory(os.path.dirname(file_path), os.path.basename(file_path))

@app.route('/control')
@login_required
def control():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('index'))
    users = User.query.all()
    cases = Case.query.order_by(Case.c_order).all()
    return render_template('control.html', users=users, cases=cases)


@app.route('/change_status/<int:case_id>/<string:status>')
@login_required
def change_status(case_id, status):
    if not current_user.is_admin:
        flash('You do not have permission to perform this action.', 'danger')
        return redirect(url_for('list_cases'))
    
    case = Case.query.get_or_404(case_id)
    try:
        new_status = CaseStatus(status)
        case.status = new_status
        db.session.commit()
        flash(f'Case status updated to {new_status.value}.', 'success')
    except ValueError:
        flash('Invalid status.', 'danger')
    
    return redirect(url_for('list_cases'))

@app.route('/manage_display')
@login_required
def manage_display():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    all_cases = Case.query.all()
    display_cases = DisplayCase.query.order_by(
        DisplayCase.custom_order.nullsfirst(), 
        DisplayCase.display_order
    ).all()
    displayed_ids = [dc.case_id for dc in display_cases]
    
    return render_template('manage_display.html', 
                         all_cases=all_cases, 
                         display_cases=display_cases,
                         displayed_ids=displayed_ids)

@app.route('/add_to_display/<int:case_id>', methods=['POST'])
@login_required
def add_to_display(case_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    # Check if case already in display
    if not DisplayCase.query.filter_by(case_id=case_id).first():
        # Get the highest display order
        highest_order = db.session.query(db.func.max(DisplayCase.display_order)).scalar()
        next_order = 1 if highest_order is None else highest_order + 1
        
        display_case = DisplayCase(case_id=case_id, display_order=next_order)
        db.session.add(display_case)
        db.session.commit()
        flash('Case added to display', 'success')
    else:
        flash('Case already in display', 'warning')
    
    return redirect(url_for('manage_display'))

@app.route('/remove_from_display/<int:case_id>', methods=['POST'])
@login_required
def remove_from_display(case_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    display_case = DisplayCase.query.filter_by(case_id=case_id).first()
    if display_case:
        removed_order = display_case.display_order
        db.session.delete(display_case)
        
        # Update remaining orders
        cases_to_update = DisplayCase.query.filter(
            DisplayCase.display_order > removed_order
        ).all()
        for case in cases_to_update:
            case.display_order -= 1
        
        db.session.commit()
        flash('Case removed from display', 'success')
    
    return redirect(url_for('manage_display'))

@app.route('/display_settings', methods=['GET', 'POST'])
@login_required
def display_settings():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    field_ar = [
        "id",
        "رقم الدعوى",
        "تاريخ الدعوى",
        "تاريخ الإضافة",
        "الترتيب",
        "تاريخ الجلسة القادمة",
        "نتيجة المحكمة",
        "رقم الجلسة",
        "موضوع الجلسة",
        "المستأنف ضدة",
        "المستأنف",
        "الرقم المقابل",
        "دائرة الشرطة",
        "رقم الشرطة",
        "الحالة"  
    ]
    
    case_fields = [column.name for column in Case.__table__.columns]
    
    if request.method == 'POST':
        DisplaySettings.query.delete()
        for field in case_fields:
            setting = DisplaySettings(
                field_name=field,
                field_name_ar=request.form.get(f'field_name_ar_{field}', ''),
                is_visible=field in request.form.getlist('visible_fields')
            )
            db.session.add(setting)
        db.session.commit()
        flash('Display settings updated successfully', 'success')
        return redirect(url_for('display_settings'))

    settings = {setting.field_name: setting for setting in DisplaySettings.query.all()}
    fields = [{
        'name': field,
        'is_visible': settings.get(field, DisplaySettings()).is_visible,
        'field_name_ar': field_ar[case_fields.index(field)] if field in case_fields else ''
    } for field in case_fields]
    
    return render_template('display_settings.html', fields=fields, field_ar=field_ar)


@app.route('/update_display_order', methods=['POST'])
@login_required
def update_display_order():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    # Get all display cases
    display_cases = DisplayCase.query.all()
    
    # Update orders based on form data
    for display_case in display_cases:
        order_key = f'order_{display_case.case_id}'
        if order_key in request.form:
            display_case.custom_order = int(request.form[order_key])
    
    db.session.commit()
    flash('Display order updated successfully', 'success')
    return redirect(url_for('manage_display'))

# Update the display and general routes to use custom_order
@app.route('/display')
def display():
    visible_fields = [s.field_name for s in DisplaySettings.query.filter_by(is_visible=True).all()]
    
    if not visible_fields:
        visible_fields = ['case_number', 'case_date', 'next_session_date', 
                         'case_subject', 'plaintiff', 'defendant', 'status']
    
    display_cases = DisplayCase.query.order_by(DisplayCase.custom_order, DisplayCase.display_order).all()
    cases = [dc.case for dc in display_cases]
    
    return render_template('display.html', cases=cases, visible_fields=visible_fields)

@app.route('/general')
def general():
    visible_fields = [s.field_name for s in DisplaySettings.query.filter_by(is_visible=True).all()]
    if not visible_fields:
        visible_fields = ['case_number', 'case_date', 'next_session_date', 'case_subject', 'plaintiff', 'defendant']
    
    #display_cases = DisplayCase.query.order_by(DisplayCase.custom_order, DisplayCase.display_order).all()
    display_cases = DisplayCase.query.join(Case).order_by(Case.c_order, DisplayCase.custom_order, DisplayCase.display_order).all()
    cases = [dc.case for dc in display_cases]
    
    field_translations = {s.field_name: s.field_name_ar for s in DisplaySettings.query.all() if s.field_name_ar}
    matching_fields = {field: field_translations.get(field, field.replace('_', ' ').title()) for field in visible_fields}
    
    return render_template('general.html', cases=cases, visible_fields=visible_fields, matching_fields=matching_fields)

# User Management Routes
@app.route('/users')
@login_required
def list_users():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    users = User.query.all()
    return render_template('users.html', users=users)

@app.route('/add_user', methods=['GET', 'POST'])
@login_required
def add_user():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        user = User(
            username=request.form['username'],
            password=generate_password_hash(request.form['password']),
            name=request.form['name'],
            email=request.form['email'],
            tel=request.form['tel'],
            is_admin=bool(request.form.get('is_admin'))
        )
        db.session.add(user)
        db.session.commit()
        flash('User added successfully', 'success')
        return redirect(url_for('list_users'))
    return render_template('add_user.html')

@app.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    user = User.query.get_or_404(user_id)
    if request.method == 'POST':
        user.username = request.form['username']
        if request.form['password']:
            user.password = generate_password_hash(request.form['password'])
        user.name = request.form['name']
        user.email = request.form['email']
        user.tel = request.form['tel']
        user.is_admin = bool(request.form.get('is_admin'))
        db.session.commit()
        flash('User updated successfully', 'success')
        return redirect(url_for('list_users'))
    return render_template('edit_user.html', user=user)

@app.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('Cannot delete your own account', 'danger')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted successfully', 'success')
    return redirect(url_for('list_users'))

# Case Management Routes
@app.route('/cases')
@login_required
def list_cases():
    cases = Case.query.order_by(Case.c_order).all()
    return render_template('cases.html', cases=cases)

@app.route('/add_case', methods=['GET', 'POST'])
@login_required
def add_case():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        highest_order = db.session.query(db.func.max(Case.c_order)).scalar()
        next_order = 1 if highest_order is None else highest_order + 1
        
        case = Case(
            case_number=request.form['case_number'],
            case_date=datetime.strptime(request.form['case_date'], '%Y-%m-%d').date(),
            c_order=next_order,
            next_session_date=request.form['next_session_date'],
            session_result=request.form['session_result'],
            num_sessions=int(request.form['num_sessions']),
            case_subject=request.form['case_subject'],
            defendant=request.form['defendant'],
            plaintiff=request.form['plaintiff'],
            prosecution_number=request.form['prosecution_number'],
            police_department=request.form['police_department'],
            police_case_number=request.form['police_case_number'],
            status=request.form.get('status', 'inactive')
        )
        db.session.add(case)
        db.session.commit()
        flash('Case added successfully', 'success')
        return redirect(url_for('list_cases'))
    return render_template('add_case.html')

@app.route('/edit_case/<int:case_id>', methods=['GET', 'POST'])
@login_required
def edit_case(case_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    case = Case.query.get_or_404(case_id)
    if request.method == 'POST':
        case.case_number = request.form['case_number']
        case.case_date = datetime.strptime(request.form['case_date'], '%Y-%m-%d').date()
        case.next_session_date = request.form['next_session_date']
        case.session_result = request.form['session_result']
        case.num_sessions = int(request.form['num_sessions'])
        case.case_subject = request.form['case_subject']
        case.defendant = request.form['defendant']
        case.plaintiff = request.form['plaintiff']
        case.prosecution_number = request.form['prosecution_number']
        case.police_department = request.form['police_department']
        case.police_case_number = request.form['police_case_number']
        case.status = request.form.get('status', 'inactive')
        case.added_date = datetime.utcnow()
        db.session.commit()
        flash('Case updated successfully', 'success')
        return redirect(url_for('list_cases'))
    return render_template('edit_case.html', case=case)

@app.route('/delete_case/<int:case_id>', methods=['POST'])
@login_required
def delete_case(case_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    case = Case.query.get_or_404(case_id)
    # First remove from display if it exists
    display_case = DisplayCase.query.filter_by(case_id=case_id).first()
    if display_case:
        removed_order = display_case.display_order
        db.session.delete(display_case)
        
        # Update display orders
        display_cases_to_update = DisplayCase.query.filter(
            DisplayCase.display_order > removed_order
        ).all()
        for dc in display_cases_to_update:
            dc.display_order -= 1
    
    # Get the order of the case being deleted
    deleted_order = case.c_order
    
    # Delete the case
    db.session.delete(case)
    
    # Update the order of remaining cases
    cases_to_update = Case.query.filter(Case.c_order > deleted_order).all()
    for case in cases_to_update:
        case.c_order -= 1
    
    db.session.commit()
    flash('Case deleted successfully', 'success')
    return redirect(url_for('list_cases'))

@app.route('/toggle_status/<int:case_id>')
@login_required
def toggle_status(case_id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    case = Case.query.get_or_404(case_id)
    case.status = 'active' if case.status == 'inactive' else 'inactive'
    db.session.commit()
    flash(f'Case status changed to {case.status}', 'success')
    
    # Check if we came from manage_display
    referrer = request.referrer
    if referrer and 'manage_display' in referrer:
        return redirect(url_for('manage_display'))
    return redirect(url_for('list_cases'))

@app.route('/reorder_display/<int:case_id>/<string:direction>', methods=['POST'])
@login_required
def reorder_display(case_id, direction):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    display_case = DisplayCase.query.filter_by(case_id=case_id).first()
    if display_case:
        current_order = display_case.display_order
        if direction == 'up' and current_order > 1:
            # Swap with previous case
            other_case = DisplayCase.query.filter_by(display_order=current_order-1).first()
            if other_case:
                other_case.display_order = current_order
                display_case.display_order = current_order - 1
        elif direction == 'down':
            # Swap with next case
            other_case = DisplayCase.query.filter_by(display_order=current_order+1).first()
            if other_case:
                other_case.display_order = current_order
                display_case.display_order = current_order + 1
        
        db.session.commit()
    
    return redirect(url_for('manage_display'))

@app.route('/drop_all_tables')
@login_required
def drop_all_tables():
    print(f"-----------------Just Testing -------------------")
    with app.app_context():
            # Drop and recreate all tables
            db.drop_all()
            db.create_all()
            
            # Create default admin if no users exist
            if not User.query.first():
                admin = User(
                    username='admin',
                    password=generate_password_hash('admin'),
                    name='Administrator',
                    email='admin@example.com',
                    tel='123456789',
                    is_admin=True
                )
                db.session.add(admin)
                db.session.commit()
                print("Default admin user created:")
                print("Username: admin")
                print("Password: admin")
                
            # Initialize default display settings
            if not DisplaySettings.query.first():
                default_fields = ['case_number', 'case_date', 'next_session_date', 
                                'case_subject', 'plaintiff', 'defendant', 'status']
                for field in default_fields:
                    setting = DisplaySettings(field_name=field, is_visible=True)
                    db.session.add(setting)
                db.session.commit()
    return redirect(url_for('index'))
if __name__ == '__main__':
    with app.app_context():
        # Drop and recreate all tables
        #db.drop_all()
        #db.create_all()
        
        # Create default admin if no users exist
        if not User.query.first():
            admin = User(
                username='admin',
                password=generate_password_hash('admin'),
                name='Administrator',
                email='admin@example.com',
                tel='123456789',
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()
            print("Default admin user created:")
            print("Username: admin")
            print("Password: admin")
            
        # Initialize default display settings
        if not DisplaySettings.query.first():
            default_fields = ['case_number', 'case_date', 'next_session_date', 
                            'case_subject', 'plaintiff', 'defendant', 'status']
            for field in default_fields:
                setting = DisplaySettings(field_name=field, is_visible=True)
                db.session.add(setting)
            db.session.commit()
            
    app.run(debug=True)